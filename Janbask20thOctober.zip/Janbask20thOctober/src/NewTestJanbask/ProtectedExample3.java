package NewTestJanbask;

import TestJanbask.ProtectedExample1;

public class ProtectedExample3 extends ProtectedExample1 {

	public static void main(String[] args) {
		
		
		
		
		
		

	}

}
