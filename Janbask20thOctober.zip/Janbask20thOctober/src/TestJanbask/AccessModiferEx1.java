package TestJanbask;

class AZ
{
	public int z=10;
	static void display()
	{
		System.out.println("Hello");
	}
}

class AY
{
	void test()
	{
		int p=z+10;
	}
}




public class AccessModiferEx1 {

	public static void main(String[] args) {
		
		AZ.display();
		
		
		
		
		
		
		
		
		

	}

}
