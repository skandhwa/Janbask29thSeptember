package TestJanbask;


class BA
{
	final int x=10;
	void display()
	{
		System.out.println("Hello");
		x=x+20;
		
	}
}



public class FinalExample {

	public static void main(String[] args) {
		
		BA obj=new BA();
		obj.display();
		
		
		

	}

}
