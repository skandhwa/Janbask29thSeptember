package TestJanbask;

public class ShortHandOperator {

	public static void main(String[] args) {
		
		int a=25;
		
		a/=5;//a=a/5
		
		System.out.println(a);
		
		
		

	}

}
