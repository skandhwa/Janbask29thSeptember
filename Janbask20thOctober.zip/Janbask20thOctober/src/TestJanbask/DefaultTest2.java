package TestJanbask;

public class DefaultTest2 {

	public static void main(String[] args) {
		
		AB obj=new AB();
		obj.display();
		
		

	}

}
