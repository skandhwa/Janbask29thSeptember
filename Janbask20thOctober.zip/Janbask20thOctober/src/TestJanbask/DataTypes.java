package TestJanbask;

public class DataTypes {

	public static void main(String[] args) {
		
		int a=20;//32 bits//4 byte
		float b=30.5f;//32 bits //4 bytes
		//String name="Saurabh";
		char ch='Y';
		boolean flag=false;
		
		
		int p=20,q=30,r=40,P=20;
		
		float g=9.85f,w=5.66f;
		
		int final=30;
		
		
		int t=p+30;
		System.out.println(t);
		
		
		
		

	}

}
