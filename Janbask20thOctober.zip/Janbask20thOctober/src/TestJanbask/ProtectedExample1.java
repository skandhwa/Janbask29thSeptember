package TestJanbask;

class AC
{
	protected void display()
	{
		System.out.println("Hello");
	}
}
public class ProtectedExample1 {

	public static void main(String[] args) {
		
		AC obj=new AC();
		obj.display();
		
		
		
		
		

	}

}
