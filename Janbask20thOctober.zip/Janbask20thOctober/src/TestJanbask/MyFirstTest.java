package TestJanbask;

import java.util.*;

public class MyFirstTest {

	public static void main(String[] args) {
		
		System.out.println("Hello");
		System.out.print("Saurabh");
		System.out.println("Manish");
		
		/*Added by Saurabh on 20th October
		
		This code will print new meesages 
		
		*/
		
		
		
		
		
		

	}

}
