package TestJanbask;

public class VariableExample3 {

	public static void main(String[] args) {
		
		int p=20;
		int q=p*20;///q=20*20=400
		int r=q-40;///r=400-40
		System.out.println(r);
		
		int a=28;
		int b=a%5;
		System.out.println(b);
		
		
		a++;
		
		a--;
		
		
		

	}

}
