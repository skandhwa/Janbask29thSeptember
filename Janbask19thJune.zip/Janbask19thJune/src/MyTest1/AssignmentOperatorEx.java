package MyTest1;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
