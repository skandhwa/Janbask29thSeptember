package MyTest1;

public class VariablesEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
