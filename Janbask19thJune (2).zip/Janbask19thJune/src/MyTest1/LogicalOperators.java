package MyTest1;

public class LogicalOperators {

	public static void main(String[] args) {
		
		int x=20;
		int y=30;
		int z=40;
		
		if(x<y  || z<x  || y<z)
		{
			System.out.println("Yes");
		}
		
		else
		{
			System.out.println("No");
		}
		

	}

}
