package MyTest1;

public class VotingApp {

	public static void main(String[] args) {
		
		int age=88;
		
		if(age>=18)
		{
			System.out.println("You are elligible to vote");
			
			if(age>60)
			{
				System.out.println("You are senior citizen ,someone will come to home to take vote");
				
				if(age>80)
				{
					System.out.println("You are super senior citizen , you can vote online");
				}
				
			}
			
		}
		
		else
		{
			System.out.println("You are eithernot elligible or you dont have voting card");
		}
		

	}

}
