package MyTest1;

public class SwitchEx {

	public static void main(String[] args) {
		
int	choice=6;
		
		switch(choice)
		{
		case 1:
			
			System.out.println("This is first choice");
            break;
            
		case 2:
			System.out.println("This is second choice");
			break;
		
		case 3:
			System.out.println("This is third choice");
			break;
		
		case 4:
			System.out.println("This is fourth choice");
			break;
			
		default:
			System.out.println("This is invalid choice");
            
		}
		
		
		

	}

}
