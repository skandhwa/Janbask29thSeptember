package MyTest1;

public class LoopSingleCondition {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		int c=40;
		
		if(a<b && a<c)
		{
			if(b<c)
			{
			
				if(a<c)
				{
					System.out.println("Yes");
				}
			
			
			
			}
			
			else
			{
				
			}
		}
		
		else
		{
			System.out.println("No");
		}
		
		

	}

}
