package MyTest1;

public class MyTest1 {
	
	void display()
	{
		System.out.println("This is display statement");
	}
	
	
	

	public static void main(String[] args) {
		
		System.out.print("Hello");
		System.out.println("Java");
		
		int a=10;
		int b=20;
		
		if(a>b)
		{
			System.out.println("a is max");
		}
		
		else
		{
			System.out.println("b is max");
		}
		
		
		

	}

}
