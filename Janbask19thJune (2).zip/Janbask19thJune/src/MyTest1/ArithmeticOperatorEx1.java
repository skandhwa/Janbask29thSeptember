package MyTest1;

public class ArithmeticOperatorEx1 {

	public static void main(String[] args) {
		
//		int x=13%5;
//		
//		System.out.println(x);
		
		System.out.println(5>10);
		

	}

}
