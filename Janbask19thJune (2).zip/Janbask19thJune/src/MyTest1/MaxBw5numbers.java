package MyTest1;

public class MaxBw5numbers {

	public static void main(String[] args) {
		
		int a=10,b=20,c=15,d=25,e=18;
		
		
		if(a>b && a>c && a>d && a>e)
		{
			System.out.println("Max is a");
		}
		
		else if(b>a && b>c && b>d && b>e)
		{
			System.out.println("Max is b");
		}
		
		else if(c>a && c>b && c>d && c>e)
		{
			System.out.println("Max is c");
		}
		
		else if(d>a && d>b && d>c && d>e)
		{
			System.out.println("Max is d");
		}
		
		else
		{
			System.out.println("Max is e");
		}
		

	}

}
