package MyTest1;

public class MyPractice {

	public static void main(String[] args) {
		
		int a=10,b=20,c=30;
		int sum=a+b+c;
	//	System.out.println(sum);
		
		int p=230;
		
		float q=34.55f;
		
		double r=1231232132.1212321321;
		
		String str="New York";
		
		char ch='H';
		
		boolean v=false;
		
		
		
		
		
		
		

	}

}
