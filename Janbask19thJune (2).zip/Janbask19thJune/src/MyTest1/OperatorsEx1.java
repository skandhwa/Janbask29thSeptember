package MyTest1;

public class OperatorsEx1 {

	public static void main(String[] args) {
		
		int a=20,b=30,c=50;
		
		if(a<b  || c>b || a>c)
		{
			System.out.println("Yes");
		}
		
		else
		{
			System.out.println("No");
		}
		
		

	}

}
