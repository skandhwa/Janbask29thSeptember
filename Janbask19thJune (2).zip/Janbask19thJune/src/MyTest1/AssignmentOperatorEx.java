package MyTest1;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		
		
		int x=10;
		
		x+=30;/// x=x+30=40
		
		x/=70;/// x=x/70

	}

}
