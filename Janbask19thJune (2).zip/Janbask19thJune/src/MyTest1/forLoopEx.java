package MyTest1;

public class forLoopEx {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++)
		{
			System.out.println(i);
		}
		

	}

}
