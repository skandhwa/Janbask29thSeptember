package MyTest1;

class B
{
	static int a=20;
	
	void sum()
	{
		int b=20;
		int c=30;
		
	}
	
}


public class VariablesEx2 {

	public static void main(String[] args) {
		
		int x=20,y=30,z=50;
		
		

	}

}
