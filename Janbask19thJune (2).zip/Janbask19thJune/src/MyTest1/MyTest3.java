package MyTest1;

public class MyTest3 {
	
	void test()
	{
		System.out.println("Hello");
	}
	
	
	void sum()
	{
		int a=20;
		int b=30;
		int c=40;
		int sum=a+b+c;
	}
	
	

	public static void main(String[] args) 
	{
		MyTest3 obj=new MyTest3();
		obj.test();
		obj.sum();

	}

}
