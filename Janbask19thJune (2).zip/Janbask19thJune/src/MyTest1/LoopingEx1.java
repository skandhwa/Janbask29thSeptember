package MyTest1;

class D1
{
	protected void sum()
	{
		
	}
	
	private int x=20;
	
}


public class LoopingEx1 {

	public static void main(String[] args) {
		
		int a=20;///code added by saurabh on 11th july
		int b=30;
		if(a>b)
		{
			System.out.println("Max is A");
		}
		
		else
		{
			System.out.println("Max is B");
		}
		
		
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
		}
		
		D1 obj1=new D1();
		obj1.x
		
		

	}

}
