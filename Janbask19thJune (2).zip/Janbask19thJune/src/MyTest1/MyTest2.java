package MyTest1;

class A
{
	void sum()
	{
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
	}
}


public class MyTest2 {

	public static void main(String[] args) {
		

	}

}
