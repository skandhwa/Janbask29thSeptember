package MyTest1;

public class DisplayHighMediumLowNum {

	public static void main(String[] args) {
		
		int a=-1500;
		
		if(a>=1 && a<=100)
		{
			System.out.println("Small");
		}
		
		else if(a>101 && a<=1000)
		{
			System.out.println("Medium");
		}
		
		else if(a>=1001 && a<=10000)
		{
			System.out.println("Large");
		}
		
		else
		{
			System.out.println("Either zero or negative");
		}
		
		

	}

}
